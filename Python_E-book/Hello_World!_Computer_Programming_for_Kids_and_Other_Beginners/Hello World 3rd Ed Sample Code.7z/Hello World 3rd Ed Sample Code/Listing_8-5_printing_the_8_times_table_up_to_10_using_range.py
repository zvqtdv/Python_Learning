# Listing_8-5_printing_the_8_times_table_up_to_10_using_range.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

for looper in range(1, 11):
    print(looper, "times 8 =", looper * 8)
