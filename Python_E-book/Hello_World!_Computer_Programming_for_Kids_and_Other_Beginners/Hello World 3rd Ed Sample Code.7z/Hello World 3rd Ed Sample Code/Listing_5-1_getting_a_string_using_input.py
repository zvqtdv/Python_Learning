# Listing_5-1_getting_a_string_using_input.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

print("Enter your name: ")
somebody = input()
print("Hi", somebody, "how are you today?")
