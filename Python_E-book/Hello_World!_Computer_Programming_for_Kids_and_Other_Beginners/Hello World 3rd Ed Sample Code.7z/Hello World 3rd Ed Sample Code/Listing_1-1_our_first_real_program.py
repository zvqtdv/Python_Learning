# Listing_1-1_our_first_real_program.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

print("I love pizza!")
print("pizza " * 20)
print("yum " * 40)
print("Buuuuurp!")
