# Listing_5-2_what_does_end_do.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

print("My ", end='')
print("name ", end='')
print("is ", end='')
print("Dave.", end='')
