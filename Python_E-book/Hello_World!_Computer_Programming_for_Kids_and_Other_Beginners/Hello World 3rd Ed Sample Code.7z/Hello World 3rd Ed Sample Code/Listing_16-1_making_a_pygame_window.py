# Listing_16-1_making_a_pygame_window.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

import pygame
pygame.init()
screen = pygame.display.set_mode([640, 480])
