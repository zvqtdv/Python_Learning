# Listing_8-7_whos_the_coolest_of_them_all.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

for cool_guy in ["Spongebob", "Spiderman", "Justin Timberlake", "My Dad"]:
    print(cool_guy, "is the coolest guy ever!")
