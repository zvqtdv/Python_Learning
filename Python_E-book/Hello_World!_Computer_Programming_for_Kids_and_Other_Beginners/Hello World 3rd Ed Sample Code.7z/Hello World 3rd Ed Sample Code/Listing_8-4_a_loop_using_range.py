# Listing_8-4_a_loop_using_range.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

for looper in range(1, 5):
    print(looper, "times 8 =", looper * 8)
