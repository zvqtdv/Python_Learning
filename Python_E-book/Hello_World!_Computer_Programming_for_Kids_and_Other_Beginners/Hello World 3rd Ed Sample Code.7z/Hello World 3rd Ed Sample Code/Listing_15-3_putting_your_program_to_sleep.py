# Listing_15-3_putting_your_program_to_sleep.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

import time
print("How ", end="")
time.sleep(2)
print("are ", end="")
time.sleep(2)
print("you ", end="")
time.sleep(2)
print("today?")
