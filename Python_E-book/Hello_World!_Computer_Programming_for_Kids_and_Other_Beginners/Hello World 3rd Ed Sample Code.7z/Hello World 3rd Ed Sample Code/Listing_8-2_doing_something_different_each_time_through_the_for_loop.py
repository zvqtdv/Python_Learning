# Listing_8-2_doing_something_different_each_time_through_the_for_loop.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

for looper in [1, 2, 3, 4, 5]:
    print(looper)
