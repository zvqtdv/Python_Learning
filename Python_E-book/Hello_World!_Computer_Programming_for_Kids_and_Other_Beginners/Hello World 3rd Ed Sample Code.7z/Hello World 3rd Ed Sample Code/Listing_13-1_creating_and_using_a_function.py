# Listing_13-1_creating_and_using_a_function.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

# Defines (creates) the function
def printMyAddress():
    print("Warren Sande")
    print("123 Main Street")
    print("Ottawa, Ontario, Canada")
    print("K2M 2E9")
    print()
printMyAddress()  # Calls (uses) the function
