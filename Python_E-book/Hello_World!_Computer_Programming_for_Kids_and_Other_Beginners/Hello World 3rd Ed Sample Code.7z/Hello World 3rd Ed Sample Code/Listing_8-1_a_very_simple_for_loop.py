# Listing_8-1_a_very_simple_for_loop.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

for looper in [1, 2, 3, 4, 5]:
    print("hello")
