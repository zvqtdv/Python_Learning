# Listing_21-1_a_program_to_print_squares_and_cubes.py
# Copyright Warren & Carter Sande, 2009-2019
# Released under MIT license   https://opensource.org/licenses/mit-license.php
# ------------

print("Number\t Square\t Cube")
for i in range(1, 11):
    print(i, '\t', i**2, '\t', i**3)
